import sys,json
from pathlib import Path
def main(argv=None):
    args=list(sys.argv[1:] if argv is None else argv)
    if not args or args[0] in ('-h','--help'):
        print('Usage: python eval_gate.py FILE.json [--min metric=value] [--max metric=value]'); return 0 if args else 2
    try: data=json.loads(Path(args.pop(0)).read_text(encoding='utf-8'))
    except Exception as e: print(f'Cannot read results: {e}'); return 2
    vals=dict(data.get('metrics',{})); vals.update({'latency_p50_ms':data.get('latency_ms',{}).get('p50'),'latency_p95_ms':data.get('latency_ms',{}).get('p95'),'sim_cost_usd':data.get('sim_cost_usd')}); failed=False;i=0
    while i<len(args):
        flag=args[i];
        if flag not in ('--min','--max') or i+1>=len(args) or '=' not in args[i+1]: print('Invalid threshold arguments');return 2
        key,v=args[i+1].split('=',1);i+=2
        try: threshold=float(v); actual=float(vals[key])
        except Exception: print(f'FAIL {key}: metric missing or non-numeric');failed=True;continue
        ok=actual>=threshold if flag=='--min' else actual<=threshold
        print(f'{"PASS" if ok else "FAIL"} {key}: {actual:.4f} {"≥" if flag=="--min" else "≤"} {threshold:.4f}');failed|=not ok
    return 1 if failed else 0
if __name__=='__main__': sys.exit(main())
